<?php
/*
 * Plugin Name:       Wordpress CRUD API
 * Plugin URI:        https://github.com/nagarjundhar-10101996
 * Description:       Handle the basics with this plugin.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            John Smith
 * Author URI:        https://github.com/nagarjundhar-10101996
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://github.com/nagarjundhar-10101996
 * Text Domain:       my-basics-plugin
 * Domain Path:       /languages
 */



add_action('admin_menu', 'test_plugin_setup_menu');




print_r( plugin_dir_url(__FILE__));
function test_plugin_setup_menu(){
   
    add_menu_page( 'Test Plugin Page', 'Test Plugin', 'manage_options', 'test-plugin', 'test_init' );
    add_submenu_page('test-plugin' , 'Page', 'new_menu_sub_item', 'manage_options', 'test_init');
}

function test_init(){
   ?>
   <!DOCTYPE HTML>
<html>
   <head>
      <script src=<?php echo plugin_dir_url(__FILE__);?>'app.js'></script>
      <style>
         #metawidget {
            border: 1px solid #cccccc;
            width: 90%;
            border-radius: 10px;
            padding: 10px;
            margin: 50px auto;
            overflow-x: scroll;
            overflow-y: scroll;
            height:400px;
         }
         table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}

th:nth-child(even),td:nth-child(even) {
  background-color: #D6EEEE;
}
      </style>
   </head>
   <body>
   <form action='' method='POST'>
   <label for='fname'>ID:</label>
   <input type='text' id='fname' name='ID'><br><br>
   <label for='lname'>PAGE:</label>
   <input type='text' id='lname' name='PAGE'><br><br>
   <input type='submit' value='Submit'>
   </form>
   

   <?php
 if( isset($_POST['PAGE']) && isset($_POST['ID']))
 {
    if(!empty($_POST['ID']))
    {
         $url = "http://localhost/wp_api/v1/page/Search?id={$_POST['ID']}" ;
         $response = wp_remote_get($url);
         foreach (json_decode(wp_remote_retrieve_body( $response )) as $key => $value) {
         //echo "<h1>$key</h1>";
         if(is_object($value)){
            echo
            "
            <div id='metawidget'></div>
            <script type='text/javascript'>
               var mw = new metawidget.Metawidget( document.getElementById( 'metawidget' ));
               mw.toInspect = ".json_encode($value->records)."
               mw.buildWidgets();
            </script>
            ";
         }
        }
         echo $url;
    }
    else if(!empty($_POST['PAGE']))
    {
         $url = "http://localhost/wp_api/v1/page/{$_POST['PAGE']}";
         $response = wp_remote_get($url);
         foreach (json_decode(wp_remote_retrieve_body( $response )) as $key => $value) {
         //echo "<h1>$key</h1>";
         if(is_object($value)){
            echo
            "
            <div id='metawidget'></div>
            <script type='text/javascript'>
               var mw = new metawidget.Metawidget( document.getElementById( 'metawidget' ));
               mw.toInspect = ".json_encode($value->records)."
               mw.buildWidgets();
            </script>
            ";
         }
        }
         echo $url;
    }
    else 
    {
      $url = "http://localhost/wp_api/v1/page";
      $response = wp_remote_get($url);
      foreach (json_decode(wp_remote_retrieve_body( $response )) as $key => $value) {
         //echo "<h1>$key</h1>";
         if(is_object($value)){
            echo
            "
            <div id='metawidget'></div>
            <script type='text/javascript'>
               var mw = new metawidget.Metawidget( document.getElementById( 'metawidget' ));
               mw.toInspect = ".json_encode($value->records)."
               mw.buildWidgets();
            </script>
            ";
         }
        }
      echo $url;

    }
    
 }
 else
 {
   $url = "http://localhost/wp_api/v1/page";
   $response = wp_remote_get($url);
      foreach (json_decode(wp_remote_retrieve_body( $response )) as $key => $value) {
         //echo "<h1>$key</h1>";
         if(is_object($value)){
            echo
            "
            <div id='metawidget'></div>
            <script type='text/javascript'>
               var mw = new metawidget.Metawidget( document.getElementById( 'metawidget' ));
               mw.toInspect = ".json_encode($value->records)."
               mw.buildWidgets().ready(function() {
                  $('#body').show();
                  $('#msg').hide();
              });
            </script>
            ";
         }
        }
   echo $url;
 }
}
function POST_DATA()  {
    echo'hh';
    
}

echo ' </body>
</html>';
?>